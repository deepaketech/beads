<?php
/**
 * Unicode Systems
 * @category   Uni
 * @package    Uni_Fileuploader
 * @copyright  Copyright (c) 2010-2011 Unicode Systems. (http://www.unicodesystems.in)
 * @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 */
//require_once 'Mage/Adminhtml/Block/Widget/Grid/Column/Filter/Text.php';

class Uni_Fileuploader_Block_Adminhtml_Widget_Grid_Column_Filter_File extends Mage_Adminhtml_Block_Widget_Grid_Column_Filter_Text {

}