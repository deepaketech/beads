<?php
class Chapagain_QuickOrder_Block_Quickorder extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
        
}
