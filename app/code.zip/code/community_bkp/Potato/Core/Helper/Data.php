<?php

class Potato_Core_Helper_Data extends Mage_Core_Helper_Abstract
{
    const POTATO_SUPPORT_EMAIL = 'support@potatocommerce.com';
    const POTATO_SUPPORT_NAME = 'Potato Team';
}