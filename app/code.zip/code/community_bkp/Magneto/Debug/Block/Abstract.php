<?php
class Magneto_Debug_Block_Abstract extends Mage_Core_Block_Template
{
    public function _getViewVars() {
        return $this->_viewVars;
    }
}
