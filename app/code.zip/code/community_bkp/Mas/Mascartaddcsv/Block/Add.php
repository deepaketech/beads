<?php 
/**
 * Mas_Mascartaddcsv extension by Makarovsoft.com
 * 
 * @category   	Mas
 * @package		Mas_Mascartaddcsv
 * @copyright  	Copyright (c) 2014
 * @license		http://makarovsoft.com/license.txt
 * @author		makarovsoft.com
 */
/**
 * Map
 *
 * @category	Mas
 * @package		Mas_Mascartaddcsv
 * 
 */
class Mas_Mascartaddcsv_Block_Add extends Mage_Catalog_Block_Product_Abstract {
	
}