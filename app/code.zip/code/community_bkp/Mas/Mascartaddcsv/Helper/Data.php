<?php 
/**
 * Mas_Mascartaddcsv extension by Makarovsoft.com
 * 
 * @category   	Mas
 * @package		Mas_Mascartaddcsv
 * @copyright  	Copyright (c) 2014
 * @license		http://makarovsoft.com/license.txt
 * @author		makarovsoft.com
 */
/**
 * Mascartaddcsv default helper
 *
 * @category	Mas
 * @package		Mas_Mascartaddcsv
 * 
 */
class Mas_Mascartaddcsv_Helper_Data extends Mage_Core_Helper_Abstract{
}