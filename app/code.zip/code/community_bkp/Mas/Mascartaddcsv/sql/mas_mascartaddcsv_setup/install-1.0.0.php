<?php 
/**
 * Mas_Mascartaddcsv extension by Makarovsoft.com
 * 
 * @category   	Mas
 * @package		Mas_Mascartaddcsv
 * @copyright  	Copyright (c) 2014
 * @license		http://makarovsoft.com/license.txt
 * @author		makarovsoft.com
 */
/**
 * Mascartaddcsv module install script
 *
 * @category	Mas
 * @package		Mas_Mascartaddcsv
 * 
 */
$this->startSetup();
$this->endSetup();