<?php 
/**
 * Mas_Masmakarovsoft extension by Makarovsoft.com
 * 
 * @category   	Mas
 * @package		Mas_Masmakarovsoft
 * @copyright  	Copyright (c) 2014
 * @license		http://makarovsoft.com/license.txt
 * @author		makarovsoft.com
 */
/** 
 * @category	Mas
 * @package		Mas_Masmakarovsoft
 * 
 */
class Mas_Masmakarovsoft_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup{
	
}