<?php 
class Mas_Masmakarovsoft_Block_Modules extends Mage_Adminhtml_Block_System_Config_Form_Fieldset {
} 